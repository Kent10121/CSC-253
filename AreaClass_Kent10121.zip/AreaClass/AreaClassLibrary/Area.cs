﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaClassLibrary
{
    public static class Area
    {
        public static double Getarea(double radius)
        {
            double p = Math.PI;
            return p * radius * radius;
        }
        public static double Getarea(int length, int width)
        {
          return length * width;
        }
        public static double Getarea(double radius, double height)
        {
            double p = Math.PI;
            return 2.0 * p * (radius * radius) * height * 2.0 * (p * (radius));
        }
    }
}
