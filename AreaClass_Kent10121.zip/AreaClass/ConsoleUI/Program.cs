﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AreaClassLibrary;

// CSC-253
// Je'Von Kent
// 9/5/2020
// This program calculates the area of shapes but
// has overloaded methods.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The area of a circle with a radius of 10 is " + Area.Getarea(10.0));
            Console.WriteLine("The area of a rectangle with a length of 5 " +
                $"and a width of 9 is " + Area.Getarea(5, 9));
            Console.WriteLine("The area of a cylinder with a radius of 8" +
                $" and height of 6 is " + Area.Getarea(8.0, 6.0));
            Console.ReadLine();


        }
    }
}
