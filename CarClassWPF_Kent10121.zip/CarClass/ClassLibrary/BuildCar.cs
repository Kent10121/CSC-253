﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BuildCar
    {
        public static Car BuildACar(Car thisCar)
        {
            bool error = true;
            do
            {
                Console.WriteLine("What is the car's year? Must be greater than 1990.");
                Console.Write("=> ");
                thisCar.Year = StandardMessages.ConvertToInt(Console.ReadLine());
                if (thisCar.Year < 1990)
                {
                    error = true;
                    Console.WriteLine("We cant accept this year!");
                }
                else
                {
                    error = false;
                }

                Console.WriteLine("What is the car's make?\nEx. Mercedes, Nissan, etc.");
                Console.Write("=> ");
                thisCar.Make = Console.ReadLine();

                Console.WriteLine("The cars speed is at 0.");
            } while (error == true);

            return thisCar;
        }
    }
}
