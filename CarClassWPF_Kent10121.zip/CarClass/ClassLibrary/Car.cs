﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Car
    {
        // Fields
        private string _make;
        private int _year;
        private int _speed;

        // Constructers
        public Car()
        {
            Year = 0;
            Make = "";
            Speed = 0;
        }
        // Custom Constructor
        public Car(int year, string make, int speed)
        {
            Year = year;
            Make = make;
            Speed = 0;
        }
        // Properties
        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }
        public int Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }
        }
        public int Speed
        {
            get
            {
                return _speed;
            }
            set
            {
                _speed = value;
            }
        }
        public void Accelerate()
        {
            Speed = Speed + 5;
        }
        public void Brake()
        {
            if (Speed >= 5)
                Speed = Speed - 5;
            else
                Console.WriteLine("The car is already stopped.");

        }
    }
}
