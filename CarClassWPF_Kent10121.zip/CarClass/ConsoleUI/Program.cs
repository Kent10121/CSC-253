﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

//CSC-253
// 10/28/2020
// Je'Von Kent
// This program will let you build a car
// and will display it to the user
// you can brake and accelerate.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Car car = new Car();
            do
            {
                Console.WriteLine(StandardMessages.Menu());

                switch (Console.ReadLine())
                {
                    case "1":
                        car = BuildCar.BuildACar(car);
                        Console.WriteLine(StandardMessages.ShowCar(car));
                        break;
                    case "2":
                        car.Accelerate();
                        Console.WriteLine($"Your car is traveling at {car.Speed} mph");
                        break;
                    case "3":
                        car.Brake();
                        Console.WriteLine($"Your car is traveling at {car.Speed} mph");
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayChoiceError());
                        break;
                }
                Console.WriteLine("Press ENTER key to continue...");
                Console.ReadLine();
            } while (exit == false);
        }
    }
}
