﻿namespace WinFormUI
{
    partial class EmployeeWinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.employeeNameLbl = new System.Windows.Forms.Label();
            this.employeePhoneNumberLbl = new System.Windows.Forms.Label();
            this.employeeAgeLbl = new System.Windows.Forms.Label();
            this.employeeNameText = new System.Windows.Forms.TextBox();
            this.employeePhoneText = new System.Windows.Forms.TextBox();
            this.EmployeeList = new System.Windows.Forms.ListBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.employeeAgeText = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.personnelDataSet = new WinFormUI.PersonnelDataSet();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter = new WinFormUI.PersonnelDataSetTableAdapters.EmployeeTableAdapter();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hourlyPayRateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // employeeNameLbl
            // 
            this.employeeNameLbl.AutoSize = true;
            this.employeeNameLbl.Location = new System.Drawing.Point(13, 25);
            this.employeeNameLbl.Name = "employeeNameLbl";
            this.employeeNameLbl.Size = new System.Drawing.Size(163, 17);
            this.employeeNameLbl.TabIndex = 0;
            this.employeeNameLbl.Text = "Enter Employee\'s Name:";
            // 
            // employeePhoneNumberLbl
            // 
            this.employeePhoneNumberLbl.AutoSize = true;
            this.employeePhoneNumberLbl.Location = new System.Drawing.Point(13, 112);
            this.employeePhoneNumberLbl.Name = "employeePhoneNumberLbl";
            this.employeePhoneNumberLbl.Size = new System.Drawing.Size(179, 17);
            this.employeePhoneNumberLbl.TabIndex = 1;
            this.employeePhoneNumberLbl.Text = "Enter Employee\'s Phone #:";
            // 
            // employeeAgeLbl
            // 
            this.employeeAgeLbl.AutoSize = true;
            this.employeeAgeLbl.Location = new System.Drawing.Point(13, 199);
            this.employeeAgeLbl.Name = "employeeAgeLbl";
            this.employeeAgeLbl.Size = new System.Drawing.Size(151, 17);
            this.employeeAgeLbl.TabIndex = 2;
            this.employeeAgeLbl.Text = "Enter Employee\'s Age:";
            // 
            // employeeNameText
            // 
            this.employeeNameText.Location = new System.Drawing.Point(182, 22);
            this.employeeNameText.Name = "employeeNameText";
            this.employeeNameText.Size = new System.Drawing.Size(156, 22);
            this.employeeNameText.TabIndex = 3;
            // 
            // employeePhoneText
            // 
            this.employeePhoneText.Location = new System.Drawing.Point(199, 112);
            this.employeePhoneText.Name = "employeePhoneText";
            this.employeePhoneText.Size = new System.Drawing.Size(163, 22);
            this.employeePhoneText.TabIndex = 4;
            // 
            // EmployeeList
            // 
            this.EmployeeList.FormattingEnabled = true;
            this.EmployeeList.ItemHeight = 16;
            this.EmployeeList.Location = new System.Drawing.Point(743, 25);
            this.EmployeeList.Name = "EmployeeList";
            this.EmployeeList.Size = new System.Drawing.Size(350, 196);
            this.EmployeeList.TabIndex = 7;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(853, 279);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(126, 65);
            this.submitButton.TabIndex = 6;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // employeeAgeText
            // 
            this.employeeAgeText.Location = new System.Drawing.Point(170, 199);
            this.employeeAgeText.Name = "employeeAgeText";
            this.employeeAgeText.Size = new System.Drawing.Size(168, 22);
            this.employeeAgeText.TabIndex = 5;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.positionDataGridViewTextBoxColumn,
            this.hourlyPayRateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.employeeBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(16, 251);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(695, 332);
            this.dataGridView1.TabIndex = 8;
            // 
            // personnelDataSet
            // 
            this.personnelDataSet.DataSetName = "PersonnelDataSet";
            this.personnelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.personnelDataSet;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "Employee ID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "Employee ID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 125;
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
            this.positionDataGridViewTextBoxColumn.HeaderText = "Position";
            this.positionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            this.positionDataGridViewTextBoxColumn.Width = 125;
            // 
            // hourlyPayRateDataGridViewTextBoxColumn
            // 
            this.hourlyPayRateDataGridViewTextBoxColumn.DataPropertyName = "Hourly Pay Rate";
            this.hourlyPayRateDataGridViewTextBoxColumn.HeaderText = "Hourly Pay Rate";
            this.hourlyPayRateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hourlyPayRateDataGridViewTextBoxColumn.Name = "hourlyPayRateDataGridViewTextBoxColumn";
            this.hourlyPayRateDataGridViewTextBoxColumn.Width = 125;
            // 
            // EmployeeWinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 690);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.employeeAgeText);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.EmployeeList);
            this.Controls.Add(this.employeePhoneText);
            this.Controls.Add(this.employeeNameText);
            this.Controls.Add(this.employeeAgeLbl);
            this.Controls.Add(this.employeePhoneNumberLbl);
            this.Controls.Add(this.employeeNameLbl);
            this.Name = "EmployeeWinForm";
            this.Text = "EmployeeWinForm";
            this.Load += new System.EventHandler(this.EmployeeWinForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.personnelDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label employeeNameLbl;
        private System.Windows.Forms.Label employeePhoneNumberLbl;
        private System.Windows.Forms.Label employeeAgeLbl;
        private System.Windows.Forms.TextBox employeeNameText;
        private System.Windows.Forms.TextBox employeePhoneText;
        private System.Windows.Forms.ListBox EmployeeList;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox employeeAgeText;
        private System.Windows.Forms.DataGridView dataGridView1;
        private PersonnelDataSet personnelDataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private PersonnelDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hourlyPayRateDataGridViewTextBoxColumn;
    }
}

