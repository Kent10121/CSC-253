﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace ConsoleUI
{
    public class BuildEmployee
    {
        public static void BuildAEmployee(List<Employee> inputList)
        {
            Employee thisEmployee = new Employee();
            bool error = true;
            do
            {
                Console.WriteLine("What is the employee's name?");
                Console.Write("=> ");
                thisEmployee.Name = Console.ReadLine();

                Console.WriteLine("What is the employee's phone number?");
                Console.Write("=> ");
                thisEmployee.PhoneNumber = Console.ReadLine();

                Console.WriteLine("What is the employees age?");
                Console.Write("=> ");
                thisEmployee.Age = StandardMessages.ConvertToInt(Console.ReadLine());

                if (thisEmployee.Age < 0)
                {
                    error = true;
                    Console.WriteLine("Age can't be less than 0!!");
                }
                else
                {
                    error = false;
                }

            } while (error == true);

            inputList.Add(thisEmployee);
        }
    }
}


