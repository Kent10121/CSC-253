﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

/**
 * Kent Je'Von 
 * CSC - 153
 * 10/27/2020
 * The program will let you enter the name, phone number and age
 * then you have a choice to display all the info back the user.
 */
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Input for the user and for the loop
            string input;
            bool exit = false;
            List<Employee> employees = new List<Employee>();

            // Process 
            do
            {
                Console.WriteLine(StandardMessages.DisplayMenu());
                // User's input
                input = Console.ReadLine();

                // Switch to the process
                switch (input)
                {
                    case "1":
                        BuildEmployee.BuildAEmployee(employees);
                        break;
                    case "2":
                        foreach(var emp in employees)
                        {
                            Console.WriteLine($"Name - {emp.Name}, Phone Number - {emp.PhoneNumber}," +
                                $" Age - {emp.Age}");
                        }
                        break;
                    case "3":
                        foreach(var x in employees)
                        {
                            Console.WriteLine(x.Age);
                        }
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayNumberError());
                        break;
                }
                
                Console.ReadLine();
            } while (exit == false);
        }
    }
}
