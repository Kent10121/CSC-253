﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

namespace WinFormUI
{
    public partial class EmployeeWinForm : Form
    {
        public EmployeeWinForm()
        {
            InitializeComponent();
        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            string name = employeeNameText.Text;
            string phoneNum = employeePhoneText.Text;
            int age = StandardMessages.ConvertToInt(employeeAgeText.Text);

            Employee employee = new Employee(name, phoneNum, age);
            EmployeeList.Items.Add(employee.ToString());
        }
    }
}
