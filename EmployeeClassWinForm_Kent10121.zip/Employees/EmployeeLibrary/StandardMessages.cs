﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Enter employee's information.\n2. Display employee info" +
                "\n3. Display average age\n4. Exit";
        }

        public static string DisplayNumberError()
        {
            return "Not a valid number!";
        }
        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}

