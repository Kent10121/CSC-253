﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalLibrary
{
    public class StandardMessages
    {
        public static double CalcStayCharges(int days)
        {
            double baseCharge;
            baseCharge = 350 * days;
            return baseCharge;
        }
        public static double CalcMiscCharges(double medCharges, double surgCharges, double labFees, double rehabCharges)
        {
            double miscCharges;
            return miscCharges = medCharges + surgCharges + labFees + rehabCharges;
        }
        public static double CalcTotalCharges(int days, double medCharges, double surgCharges, double labFees, double rehabCharges)
        {
            return CalcStayCharges(days) + CalcMiscCharges(medCharges, surgCharges, labFees, rehabCharges);
        }
    }
}
