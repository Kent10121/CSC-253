﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalLibrary;
using Xunit;

namespace HospitalTests
{
    public class ChargesTest
    {
        [Theory]
        [InlineData(5, 1750.0)]
        public void StayCharges_ShouldCalculate(int days, double expected)
        {
            // Act
            double actual = StandardMessages.CalcStayCharges(days);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData(10.0, 10.0, 10.0, 10.0, 40.0)]
        public void MiscCharges_ShouldCalculate(double medCharges, double surgCharges, double labFees, double rehabCharges, double expected)
        {
            // Act
            double actual = StandardMessages.CalcMiscCharges(medCharges, surgCharges, labFees, rehabCharges);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData(5, 10.0, 10.0, 10.0, 10.0, 1790.0)]
        public void TotalCharges_ShouldCalculate(int days, double medCharges, double surgCharges, double labFees, double rehabCharges, double expected)
        {
            double actual = StandardMessages.CalcTotalCharges(days, medCharges, surgCharges, labFees, rehabCharges);

            Assert.Equal(expected, actual);
        }
    }
}
