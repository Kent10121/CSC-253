﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RandomNumberLibrary;
using System.IO;

// CSC-253
// Kent Je'Von
// 10/4/2020
// This program I am suppose to create 
// a streamwriter that generates random 
// numbers to a text file document.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int randomNumber = 0;
                StreamWriter outputFile;
                outputFile = File.CreateText("Random Number.txt");

                Console.WriteLine("How many numbers would like to display?");
                int numOfLines = StandardMessages.ConvertToInt(Console.ReadLine());
                Random Rand = new Random();
                for (int count = 0; count < numOfLines; count++)
                {
                    randomNumber = Rand.Next(1, 101);
                    outputFile.WriteLine(randomNumber);
                }
                outputFile.Close();
                Console.WriteLine("File is Saved");
                Console.ReadLine();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }
        }
    }
}
