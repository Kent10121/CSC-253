﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

// CSC-253
// Je'Von Kent
// 9/10/2020
// This program counts the words in a sentence and 
// average number of letters you gave the string

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DisplayWordCounterAndAverageLetters());

            Console.ReadLine();
        }
        public static string DisplayWordCounterAndAverageLetters()
        {
            Console.WriteLine(StandardMessages.EnterUserInput());
            string input = Console.ReadLine();

            string[] words = input.Split(' ');
            Console.WriteLine(StandardMessages.DisplayOutputWordCount(words));

            double average = words.Average(w => w.Length);
            Math.Round(average, 2);
            return StandardMessages.DisplayAverage(average);
            
        }
    }
}
