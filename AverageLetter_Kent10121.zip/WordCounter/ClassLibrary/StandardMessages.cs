﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string EnterUserInput()
        {
            return "Enter a string: ";
        }
        public static string DisplayOutputWordCount(string[] words)
        {
            return $"The number of words in the sentence: " + words.Length;
        }
        public static string DisplayAverage(double average)
        {
            return $"The average number of  letters in each word is: " + average;
        }
    }
}
