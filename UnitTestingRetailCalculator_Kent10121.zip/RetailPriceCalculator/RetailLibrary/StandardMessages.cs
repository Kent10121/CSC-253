﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailLibrary
{
    public static class StandardMessages
    {
        public static double UserInput(string prompt)
        {
            Console.Write(prompt);
            return Convert.ToDouble(Console.ReadLine());
        }
        public static double CalculateRetail(double wholesale, double markup)
        {
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }
    }
}
