﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;
using Xunit;

namespace RetailLibrary.Test
{
    public class CalculatorTest
    {
        [Theory]
        [InlineData(10, 5, 10.5)]
        public void CalculateRetail_ShouldCalculatePrice(double wholesale, double markup, double expected)
        {
            // Act
            double actual = StandardMessages.CalculateRetail(wholesale, markup);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
