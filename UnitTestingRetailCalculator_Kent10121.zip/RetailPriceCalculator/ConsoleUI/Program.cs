﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLibrary;

// CSC-253
// Je'Von Kent
// 10/18/2020
// This program is going to display input for the price of the 
// item and percent then covert it to the retail price.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables
            double wholesale;
            double markup;
            double retailPrice;

            Console.WriteLine("Welcome to the Retail Calculator.");
            wholesale = StandardMessages.UserInput("What is the wholesale cost of the item $");
            markup = StandardMessages.UserInput("What is markup percent of the item %");
            retailPrice = StandardMessages.CalculateRetail(wholesale, markup);
            Console.WriteLine($"The retail price is ${retailPrice}");
            Console.ReadLine();
        }
    }
}
