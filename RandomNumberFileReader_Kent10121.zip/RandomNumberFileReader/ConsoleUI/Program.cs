﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

// CSC-253
// Kent Je'Von
// 10/4/2020
// This program is supposed to read from the
// previous file that I created in the 
// Random Number File Writer

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int randomNumber = 0, numOfLines = 0;
            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText(@"D:\CSC-153(C# Programming)\CSC-253(Advanced C# Programming)\RandomNumberFileWriter\ConsoleUI\bin\Debug\Random Number.txt");

                
                while (inputFile.EndOfStream == false)
                {
                    numOfLines += 1;
                    randomNumber = int.Parse(inputFile.ReadLine());
                    Console.WriteLine(randomNumber);
                }
                Console.WriteLine($"There are {numOfLines} lines of random numbers.");
                inputFile.Close();
                Console.ReadLine();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                Console.ReadLine();
            }
            
        }
    }
}
