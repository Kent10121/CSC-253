﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// CSC-253
// Je'Von Kent
// 8/26/2020
// This program calculates the population growth for each day

namespace Population
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables
            double organisms;
            double dailyInc;
            double numOfDays;

            // Input
            Console.WriteLine("What is the starting number of organisms?");
            organisms = ConvertToDouble(Console.ReadLine());
            while (organisms <= 0)
            {
                Console.WriteLine("Invalid Input\nCan't be less than or equal to 0");
                Console.WriteLine("What is the starting number of organisms?");
                organisms = ConvertToDouble(Console.ReadLine());
            }

            Console.WriteLine("What is the daily population increase?");
            dailyInc = ConvertToDouble(Console.ReadLine()) / 100;
            while (dailyInc <= 0)
            {
                Console.WriteLine("Invalid Input\nCan't be less than or equal to 0"); ;
                Console.WriteLine("What is the daily population increase?");
                dailyInc = ConvertToDouble(Console.ReadLine());
            }

            Console.WriteLine("How many days will there be to multiply?");
            numOfDays = ConvertToDouble(Console.ReadLine());
            while (numOfDays <=  0)
            {
                Console.WriteLine("Invalid Input\nCan't be less than or equal to 0"); ;
                Console.WriteLine("How many days will ther be to multiply?");
                numOfDays = ConvertToDouble(Console.ReadLine());
            }

            // Intialize final variable
            double finalPop = organisms;
            double percentInc = dailyInc;

            // Output
            for (int day = 1; day <= numOfDays; day++)
            {
                Console.WriteLine($"Day {day}: Final Population: {finalPop}");
                finalPop = finalPop + (percentInc * finalPop);
            }
            Console.ReadLine();
        }
        public static double ConvertToDouble(string input)
        {
            double output = 0.0;

            if (double.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1.0;
                return output;
            }
        }
    }
}
