﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

// CSC-253
// Je'Von Kent
// 9/9/2020
// This program counts the words in a sentence you
// gave the string

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(CountWords());
            Console.ReadLine();
        }
        public static string CountWords()
        {
            Console.WriteLine(StandardMessages.EnterUserInput());
            string input = Console.ReadLine();

            string[] words = input.Split(' ');

            return StandardMessages.DisplayOutputWordCount(words);
        }
    }
}
