﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string EnterUserInput()
        {
            return "Enter a string: ";
        }
        public static string DisplayFrequentLetter(char letter, int max)
        {
            return "The most frequent letter is " + letter + ", and shows up " + max + " times.";
        }
    }
}
