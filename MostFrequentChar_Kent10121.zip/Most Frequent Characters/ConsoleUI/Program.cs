﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DisplayFrequentCharacter());

            Console.ReadLine();
        }
        public static string DisplayFrequentCharacter()
        {
            Console.WriteLine(StandardMessages.EnterUserInput());
            string input = Console.ReadLine();

            int[] charArray = new int[256];
            for (int i = 0; i < input.Length; i++)
            {
                charArray[input[i]]++;
            }
            int max = -1;
            char letter = ' ';
            if (char.IsLetter(letter))
            {
                for(int i = 0; i < input.Length; i++)
                {
                    if(max < charArray[input[i]])
                    {
                        max = charArray[input[i]];
                        letter = input[i];
                    }
                }
            }
            
            return StandardMessages.DisplayFrequentLetter(letter, max);
        }
    }
}
