﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class StandardMessages
    {
        public static void DisplayDistance(int time, int speed)
        {
            for (int hour = 1; hour <= time; hour++)
            {
                int distance = speed * hour;
                Console.WriteLine("Hour " + hour + ":  Distance Traveled: " + distance + " miles");
            }
        }
        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
