﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

// CSC-253
// Je'Von Kent
// 9/25/2020
// This program will display the distance of how fast
// a vehicle will go in the amount of time given

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int speed;
            int time;

            Console.Write("Enter the vehicle's speed: ");
            speed = StandardMessages.ConvertToInt(Console.ReadLine());
            if(speed <= 0)
            {
                Console.WriteLine("The speed must be greater than 0." +
                    "Enter again: ");
                Console.Write("Enter the vehicle's speed: ");
                speed = StandardMessages.ConvertToInt(Console.ReadLine());
            }

            Console.Write("Enter how many hours the vehicle drove: ");
            time = StandardMessages.ConvertToInt(Console.ReadLine());
            if (time <= 0)
            {
                Console.WriteLine("The time must be greater than 0." +
                    "Enter again: ");
                Console.Write("Enter how many hours the vehicle drove: ");
                time = StandardMessages.ConvertToInt(Console.ReadLine());
            }

            StandardMessages.DisplayDistance(time, speed);
            Console.ReadLine();
        }
    }
}
