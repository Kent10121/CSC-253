﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// CSC-253
// Je'Von Kent
// 8/28/2020
// This program calculates the hospital charges
// of the amount days you spent of your stay

namespace Hospital_Charges
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variables
            int days;
            double medCharges;
            double surgCharges;
            double labFees;
            double rehabCharges;

            // Input
            Console.WriteLine("How many days did you stay at the hospital?");
            days = ConvertToInt(Console.ReadLine());
            while(days <= 0)
            {
                Console.WriteLine("Invalid Input. Days cannot be less than 0.");
                Console.WriteLine("How many days did you stay at the hospital?");

                days = ConvertToInt(Console.ReadLine());
            }
            Console.WriteLine("How much were the medication charges?");
            medCharges = Convert.ToDouble(Console.ReadLine());
            while (medCharges <= 0)
            {
                Console.WriteLine("Invalid Input. Charges cannot be less than 0.");
                Console.WriteLine("How much were the medication charges?");

                medCharges = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("How much were the surgical charges?");
            surgCharges = Convert.ToDouble(Console.ReadLine());
            while (surgCharges <= 0)
            {
                Console.WriteLine("Invalid Input. Charges cannot be less than 0.");
                Console.WriteLine("How much were the surgical charges?");

                surgCharges = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("How much were the lab fees?");
            labFees = Convert.ToDouble(Console.ReadLine());
            while (labFees <= 0)
            {
                Console.WriteLine("Invalid Input. Fees cannot be less than 0.");
                Console.WriteLine("How much were the lab fees?");

                labFees = Convert.ToDouble(Console.ReadLine());
            }
            Console.WriteLine("How much were the physical rehabilitation charges?");
            rehabCharges = Convert.ToDouble(Console.ReadLine());
            while (rehabCharges <= 0)
            {
                Console.WriteLine("Invalid Input. Charges cannot be less than 0.");
                Console.WriteLine("How much were the physical rehabilitation charges?");

                rehabCharges = Convert.ToDouble(Console.ReadLine());
            }
            double total = CalcTotalCharges(days, medCharges, surgCharges, labFees, rehabCharges);
            Console.WriteLine($"The total cost of your stay is ${total}");
            Console.ReadLine();
        }
        public static double CalcStayCharges(int days)
        {
            double baseCharge;
            baseCharge = 350 * days;
            return baseCharge;
        }
        public static double CalcMiscCharges(double medCharges, double surgCharges, double labFees, double rehabCharges)
        {
            double miscCharges;
            return miscCharges = medCharges + surgCharges + labFees + rehabCharges;
        }
        public static double CalcTotalCharges(int days, double medCharges, double surgCharges, double labFees, double rehabCharges)
        {
            return CalcStayCharges(days) + CalcMiscCharges(medCharges, surgCharges, labFees, rehabCharges);
        }
        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
