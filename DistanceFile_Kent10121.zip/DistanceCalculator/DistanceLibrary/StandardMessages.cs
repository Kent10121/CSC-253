﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DistanceLibrary
{
    public class StandardMessages
    {
        public static void DisplayDistance(int time, int speed)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("DistanceCalculator.txt");

                for (int hour = 1; hour <= time; hour++)
                {
                    int distance = speed * hour;
                    outputFile.WriteLine("Hour " + hour + ":  Distance Traveled: " + distance + " miles");
                }
                outputFile.Close();
                Console.WriteLine("File Created.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }
        public static int ConvertToInt(string input)
        {
            int output = 0;

            if (int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                output = -1;
                return output;
            }
        }
    }
}
