﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

// CSC-253 
// Je'Von Kent
// 9/20/2020
// This program will translate your sentence from English
// to Pig Latin

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(StandardMessages.EnterUserInput());
            string input = Console.ReadLine();

            string[] words = input.Split(' ');
            Console.Write("Pig Latin: ");
            foreach(string word in words)
            {
                Console.Write(word.ToUpper().Substring(1) + word.ToUpper().Substring(0, 1) + "AY ");
            }
            Console.ReadLine();
        }
    }
}
